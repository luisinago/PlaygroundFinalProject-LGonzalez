from django.contrib import admin
from Personajes.models import Sailor

admin.site.register(Sailor)
